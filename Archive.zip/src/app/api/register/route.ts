import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { isCampaignActive } from '@/lib/session'

const IS_PRODUCTION = process.env.APP_ENV === 'production'

export async function POST(req: NextRequest) {
  const { phone, name, email, newsConsent, deviceId } = await req.json()
  if (!phone || !name || !email)
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })

  const active = await isCampaignActive()
  if (!active) return NextResponse.json({ error: 'Campaign is not active' }, { status: 403 })

  // Device block check (production only)
  if (IS_PRODUCTION && deviceId) {
    const blocked = await prisma.participant.findFirst({
      where: { deviceId },
      include: { abuse: true },
    })
    if (blocked?.abuse?.blockedUntil && blocked.abuse.blockedUntil > new Date()) {
      return NextResponse.json(
        { error: 'This device is temporarily restricted. Please try again later.' },
        { status: 429 }
      )
    }
  }

  const existing = await prisma.participant.findUnique({ where: { phone } })
  if (existing) return NextResponse.json({ participantId: existing.id })

  const participant = await prisma.participant.create({
    data: {
      phone, name, email,
      deviceId: deviceId ?? null,
      entries: { create: { type: 'QR' } },
    },
  })

  return NextResponse.json({ participantId: participant.id }, { status: 201 })
}
